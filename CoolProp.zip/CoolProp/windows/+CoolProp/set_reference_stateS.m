function varargout = set_reference_stateS(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(356,varargin{:});
end
