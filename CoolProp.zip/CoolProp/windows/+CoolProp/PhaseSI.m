function varargout = PhaseSI(varargin)
  [varargout{1:max(1,nargout)}] = CoolPropMATLAB_wrap(358,varargin{:});
end
