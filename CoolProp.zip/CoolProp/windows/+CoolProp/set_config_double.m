function varargout = set_config_double(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(450,varargin{:});
end
