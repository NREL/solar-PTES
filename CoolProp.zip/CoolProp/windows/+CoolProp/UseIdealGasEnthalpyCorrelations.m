function varargout = UseIdealGasEnthalpyCorrelations(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(459,varargin{:});
end
