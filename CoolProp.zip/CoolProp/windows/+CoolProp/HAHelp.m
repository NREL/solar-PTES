function varargout = HAHelp(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(460,varargin{:});
end
