function varargout = split_input_pair(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(158,varargin{:});
end
