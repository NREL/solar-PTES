function varargout = set_mixture_binary_pair_data(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(160,varargin{:});
end
