function varargout = get_debug_level(varargin)
  [varargout{1:max(1,nargout)}] = CoolPropMATLAB_wrap(347,varargin{:});
end
