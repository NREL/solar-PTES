function varargout = get_config_as_json_string(varargin)
  [varargout{1:max(1,nargout)}] = CoolPropMATLAB_wrap(448,varargin{:});
end
