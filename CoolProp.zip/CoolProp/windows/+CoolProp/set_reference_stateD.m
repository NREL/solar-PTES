function varargout = set_reference_stateD(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(357,varargin{:});
end
