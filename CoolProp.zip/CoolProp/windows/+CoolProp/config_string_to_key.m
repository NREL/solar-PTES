function varargout = config_string_to_key(varargin)
  [varargout{1:max(1,nargout)}] = CoolPropMATLAB_wrap(430,varargin{:});
end
