function varargout = set_warning_string(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(350,varargin{:});
end
