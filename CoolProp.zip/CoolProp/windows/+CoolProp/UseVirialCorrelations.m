function varargout = UseVirialCorrelations(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(457,varargin{:});
end
