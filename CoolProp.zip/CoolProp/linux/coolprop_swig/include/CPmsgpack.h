// Workaround MSVC warnings
#ifdef _MSC_VER
  #pragma warning(push)
  #pragma warning(disable:4267)
#endif

#include "msgpack.hpp"

#ifdef _MSC_VER
  #pragma warning(pop)
#endif
