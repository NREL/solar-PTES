% PLOT HEX T-Q's

if Load.mode == 3
    plot_hex(HX(ihx_JB+4),3,30,'C')
end