classdef sink_class
    properties
        DHdot = 0
    end
end